"""One point per observed contract; missing reverse fee omitted, not zero."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];rows=list(csv.DictReader((ROOT/'data/clean/deals.csv').open()))
for k,label,name in [('target_fee_pct','Ordinary target termination fee','target_fees'),('buyer_fee_max_pct','Maximum buyer termination fee','buyer_fees')]:
    fig,ax=plt.subplots(figsize=(7.2,4.1));
    obs=[r for r in rows if r[k]!='']; y=list(range(len(obs)))
    for i,r in enumerate(obs):ax.scatter(float(r[k]),i,marker='o' if r['completed']=='1' else 'X',s=65,label=None,color='#28536b' if r['completed']=='1' else '#a33b20')
    ax.set_yticks(y,[r['target'] for r in obs]);ax.invert_yaxis();ax.set_xlim(left=0);ax.set_xlabel('Fee / reported XBMA deal value (%)');ax.set_title(label);ax.grid(axis='x',alpha=.22)
    ax.scatter([],[],color='#28536b',label='Completed');ax.scatter([],[],color='#a33b20',marker='X',label='Terminated');ax.legend(loc='lower right',frameon=False)
    fig.text(.02,.015,'Initial agreements; 2022 fixed mega-deal frame. Missing buyer fee omitted.' if 'buyer' in k else 'Initial agreements; 2022 fixed mega-deal frame.',fontsize=8)
    fig.tight_layout(rect=[0,.045,1,1]);fig.savefig(ROOT/'outputs'/f'{name}.png',dpi=160);plt.close(fig)
