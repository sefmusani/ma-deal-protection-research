"""Validate and parse the frozen browser-transcribed source notes (not full HTML)."""
import csv,json,re,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw'; OUT=ROOT/'data/clean'; OUT.mkdir(exist_ok=True)
def amount(token):
    m=re.fullmatch(r'\$([0-9,]+)( million)?',token)
    if not m: raise ValueError(token)
    return int(m[1].replace(',',''))*(1_000_000 if m[2] else 1)
rows=json.loads((RAW/'observations.json').read_text())
assert len(rows)==9 and len({r['rank'] for r in rows})==9
for r in rows:
    assert r['agreement_accession'] in r['agreement_url'] and r['outcome_accession'] in r['outcome_url']
    r['target_fee_usd']=amount(r['target_fee_token'])
    tiers=list(map(amount,r['buyer_fee_tokens']))
    r['buyer_fee_max_usd']=max(tiers) if tiers else None
    r['buyer_fee_min_usd']=min(tiers) if tiers else None
checks=list(csv.DictReader((RAW/'crosschecks.csv').open()))
seeded=random.Random(20221123).sample(sorted(r['rank'] for r in rows),3)
assert set(seeded)=={int(c['rank']) for c in checks if c['seeded_audit_sample']=='1'}
n=bad=sn=sb=0
for c in checks:
    r=next(r for r in rows if r['rank']==int(c['rank']))
    for k in ('target_fee_usd','buyer_fee_max_usd'):
        if c[k]:
            err=int(c[k])!=r[k]; n+=1;bad+=err
            if r['rank'] in seeded:sn+=1;sb+=err
assert bad==0
(OUT/'parsed.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
(OUT/'validation.json').write_text(json.dumps(dict(seed=20221123,seeded_ranks=seeded,seeded_fields=sn,seeded_errors=sb,total_fields=n,total_errors=bad),indent=2)+'\n')
print(f'Parsed {len(rows)} rows; {bad}/{n} cross-check mismatches; seeded sample {sb}/{sn}.')
