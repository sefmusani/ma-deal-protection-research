"""Descriptive analysis; no regression with only one termination."""
import csv,json,statistics as s,itertools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; O=ROOT/'outputs';O.mkdir(exist_ok=True)
rows=list(csv.DictReader((ROOT/'data/clean/deals.csv').open()))
cols=['target_fee_pct','buyer_fee_max_pct','buyer_fee_min_pct','elapsed_days','value_usd_m','pandemic_exclusion']
def values(rs,k):return [float(r[k]) for r in rs if r[k]!='']
def stats(rs,k):
    a=values(rs,k);return dict(n=len(a),mean=s.mean(a) if a else None,median=s.median(a) if a else None,min=min(a) if a else None,max=max(a) if a else None)
def diff(rs,k):
    a=values([r for r in rs if r['completed']=='1'],k);b=values([r for r in rs if r['completed']=='0'],k)
    return s.mean(a)-s.mean(b) if a and b else None
complete=[r for r in rows if r['completed']=='1']; failed=[r for r in rows if r['completed']=='0']
assert len(complete)==8 and len(failed)==1
summary={g:{k:stats(rs,k) for k in cols} for g,rs in [('all',rows),('completed',complete),('terminated',failed)]}
diffs={k:diff(rows,k) for k in cols}
# Enumerate all assignments preserving group counts. Diagnostic only, not random assignment.
x=values(rows,'target_fee_pct'); obs=diffs['target_fee_pct']; assignments=[]
for ix in itertools.combinations(range(len(x)),len(failed)):
    a=[v for i,v in enumerate(x) if i not in ix];b=[x[i] for i in ix];assignments.append(s.mean(a)-s.mean(b))
p=sum(abs(v)>=abs(obs)-1e-12 for v in assignments)/len(assignments)
loo=[dict(omitted=r['target'],target_diff=diff([z for z in rows if z is not r],'target_fee_pct'),buyer_diff=diff([z for z in rows if z is not r],'buyer_fee_max_pct')) for r in rows]
robust={'exclude_nielsen':{k:diff([r for r in rows if r['rank']!='10'],k) for k in cols[:3]},'buyer_missing_as_zero_hypothetical':diff([dict(r,buyer_fee_max_pct=r['buyer_fee_max_pct'] or '0') for r in rows],'buyer_fee_max_pct'),'lowest_buyer_tier':diffs['buyer_fee_min_pct']}
result=dict(summary=summary,differences=diffs,permutation_two_sided=p,permutation_assignments=assignments,leave_one_out=loo,robustness=robust,regression='Withheld: only 1 termination; pandemic indicator constant',completion_rate=len(complete)/len(rows))
(O/'results.json').write_text(json.dumps(result,indent=2)+'\n')
with (O/'descriptives.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['group','variable','n','mean','median','min','max']);
 for g,ss in summary.items():
  for k,t in ss.items():w.writerow([g,k,*t.values()])
with (O/'leave_one_out.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(loo[0]));w.writeheader();w.writerows(loo)
print(json.dumps({'differences':diffs,'permutation':p,'robustness':robust},indent=2))
