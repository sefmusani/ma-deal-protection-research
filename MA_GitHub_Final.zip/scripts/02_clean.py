"""Enforce the fixed frame, compute percentages and elapsed calendar days."""
import csv,json,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; D=ROOT/'data/clean'
frame=list(csv.DictReader((ROOT/'data/raw/frame.csv').open())); rows=json.loads((D/'parsed.json').read_text())
assert len(frame)==10 and set(map(int,[x['rank'] for x in frame]))==set(range(1,11))
eligible={int(x['rank']):x for x in frame if x['eligible']=='1'}
assert set(eligible)=={x['rank'] for x in rows}
for r in rows:
    f=eligible[r['rank']]; assert float(f['value_usd_m'])==r['value_usd_m'] and f['target']==r['target']
    d=datetime.date.fromisoformat; r['elapsed_days']=(d(r['outcome_date'])-d(r['signing_date'])).days
    assert r['elapsed_days']>=0 and d(r['outcome_date'])<=d('2025-12-31')
    for k in ['target_fee','buyer_fee_max','buyer_fee_min']:
        v=r[k+'_usd'];r[k+'_pct']=100*v/(r['value_usd_m']*1e6) if v is not None else None
    r['buyer_fee_tokens']='; '.join(r['buyer_fee_tokens'])
fields=list(dict.fromkeys(k for r in rows for k in r))
with (D/'deals.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
with (D/'exclusions.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(frame[0]));w.writeheader();w.writerows(x for x in frame if x['eligible']=='0')
print('9 eligible; 1 private exclusion; 0 missing outcomes; 1 buyer fee unconfirmed.')
