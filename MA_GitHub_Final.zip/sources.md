# Source register

Browser retrieval: 2026-11-23. Literature reviewed at abstract/accessible text level, not a comprehensive full-text review. Judicial opinions are primary text reproduced by Justia. SEC accessions are directory identifiers (without hyphens). URLs were located during research; automated HTTP validation was unavailable.

## Literature, law, frame and other resources

- XBMA (2023). Annual Review 2022, printed p. 15. Sampling frame (industry report; deal value methodology not harmonized). [Link](https://xbma.org/wp-content/uploads/2023/01/XBMA-Annual-Review-2022-1.pdf)
- Bates, T. W., & Lemmon, M. L. (2003). Breaking up is hard to do? An analysis of termination fee provisions and merger outcomes. Journal of Financial Economics, 69(3), 469–504. Institutional abstract. [Link](https://experts.azregents.edu/en/publications/breaking-up-is-hard-to-do-an-analysis-of-termination-fee-provisio)
- Officer, M. S. (2003). Termination fees in mergers and acquisitions. Journal of Financial Economics, 69(3), 431–467. Bibliographic record; abstract located via publisher search, full text unavailable. [Link](https://ideas.repec.org/a/eee/jfinec/v69y2003i3p431-467.html)
- Miller, R. T. (2009). The economics of deal risk: Allocating risk through MAC clauses in business combination agreements. William & Mary Law Review, 50, 2007. [Link](https://scholarship.law.wm.edu/wmlr/vol50/iss6/4)
- Coates, J. C., IV, Palia, D., & Wu, G. (2017). Reverse termination fees in M&A: Design, signals, and bidder returns. Working paper listing; not cited as peer-reviewed. [Link](https://hls.harvard.edu/bibliography/reverse-termination-fees-in-ma-design-signals-and-bidder-returns/)
- In re Toys “R” Us, Inc. S’holder Litig., 877 A.2d 975 (Del. Ch. 2005). Court opinion reproduced by Justia. [Link](https://law.justia.com/cases/delaware/court-of-chancery/2005/62560-1.html)
- Akorn, Inc. v. Fresenius Kabi AG, C.A. No. 2018-0300-JTL (Del. Ch. Oct. 1, 2018). Court opinion. [Link](https://law.justia.com/cases/delaware/court-of-chancery/2018/ca-2018-0300-jtl.html)
- Akorn, Inc. v. Fresenius Kabi AG, No. 535, 2018 (Del. Dec. 7, 2018). Affirmance. [Link](https://law.justia.com/cases/delaware/supreme-court/2018/535-2018.html)
- SEC. Accessing EDGAR data. [Link](https://www.sec.gov/search-filings/edgar-search-assistance/accessing-edgar-data)
- Albertsons: termination notice filed December 10, 2024. [Link](https://www.sec.gov/Archives/edgar/data/1646972/000164697224000231/aci-20241210.htm)
- Kroger: December 2024 8-K, disputed fee. [Link](https://www.sec.gov/Archives/edgar/data/56873/000110465924127669/tm2427516d10_8k.htm)
- Johnson & Johnson: ABIOMED tender offer materials, contingent value right. [Link](https://www.sec.gov/Archives/edgar/data/200406/000119312522285216/d411777dex99a1a.htm)
- Adobe: quarterly report describing Figma as privately held. [Link](https://www.sec.gov/Archives/edgar/data/796343/000079634323000055/adbe-20230303.htm)
- CU Boulder Undergraduate Research Opportunities Program. [Link](https://www.colorado.edu/researchinnovation/undergraduate-research-opportunities-program-urop)
- CU Boulder UROP presentation opportunities. [Link](https://www.colorado.edu/urop/engaging/student-grant-acceptance/scholars-guide/presentation-opportunities)
- CU Boulder UROP publication opportunities. [Link](https://www.colorado.edu/urop/engaging/student-grant-acceptance/scholars-guide/publication-opportunities)
- NCUR 2027 conference portal. [Link](https://ncur.secure-platform.com/2027/)
- NCUR 2027 abstract guidelines. [Link](https://ncur.secure-platform.com/2027/page/abstract-guidelines)
- SSRN submission help. [Link](https://www.elsevier.support/ssrn/answer/get-started)

## Deal-level sources

### 1. Activision Blizzard / Microsoft
- Initial agreement, accession 000110465922005156: [EDGAR](https://www.sec.gov/Archives/edgar/data/718877/000110465922005156/tm223212d8_ex2-1.htm)
- Outcome filing, accession 000110465923108985: [EDGAR](https://www.sec.gov/Archives/edgar/data/718877/000110465923108985/tm2328253d1_8k.htm)
- Separate filing summary, accession 000110465922036155: [EDGAR](https://www.sec.gov/Archives/edgar/data/718877/000110465922036155/tm225196-4_defm14a.htm)
- Fee locator: Company Termination Fee; Parent Termination Fee. MAE locator: Company MAE clause (vii); pandemic exclusion.

### 2. VMware / Broadcom
- Initial agreement, accession 000119312522161168: [EDGAR](https://www.sec.gov/Archives/edgar/data/1124610/000119312522161168/d362256dex21.htm)
- Outcome filing, accession 000119312523282097: [EDGAR](https://www.sec.gov/Archives/edgar/data/1124610/000119312523282097/d559518d8k.htm)
- Fee locator: Termination Fee; Parent Termination Fee definitions. MAE locator: Company MAE clause (g); pandemic exclusion.

### 3. Twitter / X Holdings I
- Initial agreement, accession 000119312522120461: [EDGAR](https://www.sec.gov/Archives/edgar/data/1418091/000119312522120461/d310843dex21.htm)
- Outcome filing, accession 000119312522272772: [EDGAR](https://www.sec.gov/Archives/edgar/data/1418091/000119312522272772/d411753d8k.htm)
- Separate filing summary, accession 000119312522202163: [EDGAR](https://www.sec.gov/Archives/edgar/data/1418091/000119312522202163/d283119ddefm14a.htm)
- Fee locator: Company and Parent Termination Fee definitions. MAE locator: Company MAE clause (v); pandemic exclusion.

### 4. Duke Realty / Prologis
- Initial agreement, accession 000119312522172478: [EDGAR](https://www.sec.gov/Archives/edgar/data/783280/000119312522172478/d286771dex21.htm)
- Outcome filing, accession 000110465922105242: [EDGAR](https://www.sec.gov/Archives/edgar/data/783280/000110465922105242/tm2227228d1_8k.htm)
- Separate filing summary, accession 000119312522172478: [EDGAR](https://www.sec.gov/Archives/edgar/data/783280/000119312522172478/d286771d8k.htm)
- Fee locator: Termination Fee definitions. MAE locator: Company MAE clause (v); pandemic exclusion.

### 5. Albertsons / Kroger
- Initial agreement, accession 000119312522262645: [EDGAR](https://www.sec.gov/Archives/edgar/data/1646972/000119312522262645/d344993dex21.htm)
- Outcome filing, accession 000155837025004267: [EDGAR](https://www.sec.gov/Archives/edgar/data/56873/000155837025004267/R27.htm)
- Fee locator: Section 8.4(d); termination fee provisions. MAE locator: Company MAE clause (E); explicit COVID-19.

### 7. ABIOMED / Johnson & Johnson
- Initial agreement, accession 000119312522274497: [EDGAR](https://www.sec.gov/Archives/edgar/data/815094/000119312522274497/d395522dex21.htm)
- Outcome filing, accession 000119312522311074: [EDGAR](https://www.sec.gov/Archives/edgar/data/815094/000119312522311074/d353287d8k.htm)
- Separate filing summary, accession 000119312522274491: [EDGAR](https://www.sec.gov/Archives/edgar/data/200406/000119312522274491/d395813d8k.htm)
- Fee locator: Section 9.3(b). MAE locator: Company MAE clause (e); pandemic exclusion.

### 8. Citrix / Elliott / Vista
- Initial agreement, accession 000119312522023498: [EDGAR](https://www.sec.gov/Archives/edgar/data/877890/000119312522023498/d273843dex21.htm)
- Outcome filing, accession 000119312522256805: [EDGAR](https://www.sec.gov/Archives/edgar/data/877890/000119312522256805/d393433d8k.htm)
- Separate filing summary, accession 000119312522077283: [EDGAR](https://www.sec.gov/Archives/edgar/data/877890/000119312522077283/d219122ddefm14a.htm)
- Fee locator: Company and Parent Termination Fee definitions. MAE locator: Company MAE clause (I); pandemic exclusion.

### 9. Black Knight / Intercontinental Exchange
- Initial agreement, accession 000119312522142983: [EDGAR](https://www.sec.gov/Archives/edgar/data/1571949/000119312522142983/d307019dex21.htm)
- Outcome filing, accession 000119312523231558: [EDGAR](https://www.sec.gov/Archives/edgar/data/1571949/000119312523231558/d496275d8k.htm)
- Fee locator: Section 8.03 definitions (m), (z). MAE locator: Company MAE §8.03(s)(viii); defined Pandemic.

### 10. Nielsen / Elliott / Brookfield
- Initial agreement, accession 000119312522089952: [EDGAR](https://www.sec.gov/Archives/edgar/data/1492633/000119312522089952/d301133dex21.htm)
- Outcome filing, accession 000119312522260583: [EDGAR](https://www.sec.gov/Archives/edgar/data/1492633/000119312522260583/d407513d8k.htm)
- Separate filing summary, accession 000119312522089952: [EDGAR](https://www.sec.gov/Archives/edgar/data/1492633/000119312522089952/d301133d8k.htm)
- Fee locator: Company Termination Fee; Parent Financing Termination Fee definitions. MAE locator: Company MAE clause (viii); pandemic exclusion.

